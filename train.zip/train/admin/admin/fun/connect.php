<?php

$server_name = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'more';
$conn = new mysqli($server_name,$db_user,$db_pass,$db_name);
